=======
Credits
=======

Development Lead
----------------

* Vadim Kravcenko <vadim.kravcenko@gmail.com>

Contributors
------------

* Jake Teo <mapattacker@gmail.com>
* Jerome Chan <cjerome94@gmail.com>
